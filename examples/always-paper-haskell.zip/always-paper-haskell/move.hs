main = putStr "paper"
